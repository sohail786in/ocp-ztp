#  OCP gitops ZTP
