# Secrets folders

save files as 
- pull.json
- <clustername>-bmc-<clusterrole>.env
